import { ResultService } from "./result.service.js";
import puppeteer from "puppeteer";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

export const ResultController = {
  create: async (req, res) => {
    try {
      const result = await ResultService.createResult(req.body);
      res.json({ success: true, data: result });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to save test result" });
    }
  },

  getById: async (req, res) => {
    try {
      const result = await ResultService.fetchById(req.params.id);
      res.json({ success: true, data: result });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch test result" });
    }
  },

find: async (req, res) => {
  try {
    const { orderId, testId, patientId } = req.query;

    if (!orderId || !testId || !patientId) {
      return res.status(400).json({
        success: false,
        message: "orderId, testId and patientId are required",
      });
    }

    const result = await ResultService.findByOrderTestAndPatient(
      Number(orderId),
      Number(testId),
      Number(patientId)
    );

    res.json({ success: true, data: result });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      message: "Failed to fetch result",
    });
  }
},

find1: async (req, res) => {
  try {
    const { orderId, patientId, type = "full" } = req.query;

    if (!orderId || !patientId) {
      return res.status(400).json({
        success: false,
        message: "orderId and patientId are required",
      });
    }

    const row = await prisma.patientReportPdf.findUnique({
      where: {
        orderId_patientId: {
          orderId: Number(orderId),
          patientId: Number(patientId),
        },
      },
    });
  

    if (!row) {
      return res.status(404).json({
        success: false,
        message: "Patient PDF not found (not generated yet)",
      });
    }

    const url =
      type === "plain"
        ? row.plainPdfUrl
        : type === "letterhead"
        ? row.letterheadPdfUrl
        : row.fullPdfUrl;

    if (!url) {
      return res.status(404).json({
        success: false,
        message: `PDF url not available for type=${type}`,
      });
    }

    return res.json({
      success: true,
      data: {
        orderId: row.orderId,
        patientId: row.patientId,
        type,
        url,
        status: row.status,
      },
    });
  } catch (err) {
    console.error("patientReportPdf.find error:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch patient pdf url",
    });
  }
},

 // UPDATE RESULT
  update: async (req, res) => {
    try {
      const id = Number(req.params.id);
      const data = await ResultService.update(id, req.body);
      return res.json({ success: true, data });
    } catch (err) {
      return res.status(500).json({ success: false, message: err.message });
    }
  },

print: async (req, res) => {
  try {
    const report = await ResultService.fetchById(req.params.id);

    if (!report) return res.status(404).send("Report not found");

    const html = ResultService.generatePrintableHtml(report);

    res.set("Content-Type", "text/html");
    res.send(html);

  } catch (err) {
    console.error(err);
    res.status(500).send("Failed to print report");
  }
},

download: async (req, res) => {
  try {
    const report = await ResultService.fetchById(req.params.id);

    if (!report) return res.status(404).send("Report not found");

    const html = ResultService.generatePrintableHtml(report);

    res.setHeader("Content-Type", "application/octet-stream");
    res.setHeader("Content-Disposition", `attachment; filename=report-${report.id}.html`);
    res.send(html);

  } catch (err) {
    console.error(err);
    res.status(500).send("Failed to download report");
  }
},
 downloadPdf: async (req, res) => {
    try {
      const result = await ResultService.fetchById(req.params.id);
      if (!result) return res.status(404).send("Report not found");
    const withLetterhead = req.query.letterhead === "true";

    const layout = withLetterhead
      ? await ResultService.getDefaultLayout()
      : null;

      const defaultSignature = await prisma.eSignature.findFirst({
     where: { isDefault: true },
     });

      // Generate the HTML using your existing service
      const html = ResultService.generatePrintableHtml(result, layout, defaultSignature);

      // Launch Puppeteer
      const browser = await puppeteer.launch({
        headless: true,
        args: [
          "--no-sandbox",
          "--disable-setuid-sandbox",
        ]
      });

      const page = await browser.newPage();
      await page.setContent(html, { waitUntil: "networkidle0" });

      // Generate PDF
      const pdfBuffer = await page.pdf({
        format: "A4",
        printBackground: true,
       margin: { top: "0mm", bottom: "0mm", left: "0mm", right: "0mm" }
      });

      await browser.close();

      // Send PDF to browser
      res.set({
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename=report-${result.id}.pdf`,
      });

      res.send(pdfBuffer);

    } catch (err) {
      console.error(err);
      res.status(500).send("Failed to download PDF");
    }
  },
  

  htmlReport: async (req, res) => {
    try {
      const report = await ResultService.fetchById(req.params.id);

      // PATHOLOGY TABLE
      const rows = report.parameterResults
        .map(
          (x) => `
          <tr>
            <td>${x.parameterId}</td>
            <td>${x.valueNumber ?? x.valueText ?? ""}</td>
            <td>${x.normalRangeText ?? ""}</td>
            <td>${x.flag ?? ""}</td>
          </tr>`
        )
        .join("");

      const html = `
        <html>
          <body>
            <h2>${report.test.name}</h2>
            <p><b>Patient:</b> ${report.patient.fullName}</p>
            <hr/>
            <table border="1" cellpadding="6" cellspacing="0">
              <tr>
                <th>Parameter</th>
                <th>Value</th>
                <th>Normal Range</th>
                <th>Flag</th>
              </tr>
              ${rows}
            </table>
          </body>
        </html>`;

      res.set("Content-Type", "text/html");
      res.send(html);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to generate HTML" });
    }
  },
};
