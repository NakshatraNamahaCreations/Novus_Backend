-- AlterTable
ALTER TABLE "Doctor" ADD COLUMN     "patientId" INTEGER;
