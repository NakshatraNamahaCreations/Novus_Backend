-- AlterTable
ALTER TABLE "EarningsHistory" ADD COLUMN     "type" TEXT DEFAULT 'Credit';
