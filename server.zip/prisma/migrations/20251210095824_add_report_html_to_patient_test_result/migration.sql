-- AlterTable
ALTER TABLE "PatientTestResult" ADD COLUMN     "reportHtml" TEXT;
