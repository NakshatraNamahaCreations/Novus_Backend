-- AlterTable
ALTER TABLE "Checkup" ADD COLUMN     "spotlight" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "Package" ADD COLUMN     "spotlight" BOOLEAN NOT NULL DEFAULT false;
