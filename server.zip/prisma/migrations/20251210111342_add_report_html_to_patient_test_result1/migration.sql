-- AlterTable
ALTER TABLE "OrderMemberPackage" ADD COLUMN     "resultAdded" BOOLEAN NOT NULL DEFAULT false;
