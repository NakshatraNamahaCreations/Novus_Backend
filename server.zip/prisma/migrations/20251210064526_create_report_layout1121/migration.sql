-- AlterTable
ALTER TABLE "Order" ALTER COLUMN "addressId" DROP NOT NULL;
