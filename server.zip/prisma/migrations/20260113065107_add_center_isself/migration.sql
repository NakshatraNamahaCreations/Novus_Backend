-- AlterTable
ALTER TABLE "Center" ADD COLUMN     "isSelf" BOOLEAN NOT NULL DEFAULT false;
