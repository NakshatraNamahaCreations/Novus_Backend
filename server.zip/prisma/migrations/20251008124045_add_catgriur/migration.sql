-- AlterTable
ALTER TABLE "Category" ADD COLUMN     "type" TEXT;
