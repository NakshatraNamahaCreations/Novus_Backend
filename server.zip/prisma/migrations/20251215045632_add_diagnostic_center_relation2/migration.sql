-- AlterTable
ALTER TABLE "Checkup" ADD COLUMN     "alsoKnowAs" TEXT;
