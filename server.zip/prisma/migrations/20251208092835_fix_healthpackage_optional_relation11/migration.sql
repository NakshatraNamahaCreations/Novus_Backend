-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "assignmentNotes" TEXT;
