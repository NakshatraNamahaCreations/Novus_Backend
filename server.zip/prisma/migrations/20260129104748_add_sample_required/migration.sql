-- AlterTable
ALTER TABLE "Checkup" ADD COLUMN     "preparations" TEXT,
ADD COLUMN     "sampleRequired" TEXT;
