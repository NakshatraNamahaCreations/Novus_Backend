-- AlterTable
ALTER TABLE "order_tracking" ADD COLUMN     "lastMetrics" JSONB;
