-- AlterTable
ALTER TABLE "Patient" ADD COLUMN     "alcoholConsumption" TEXT,
ADD COLUMN     "exerciseFrequency" TEXT,
ADD COLUMN     "height" TEXT,
ADD COLUMN     "smokingHabit" TEXT,
ADD COLUMN     "weight" TEXT;
