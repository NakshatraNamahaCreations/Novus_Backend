-- AlterTable
ALTER TABLE "Package" ADD COLUMN     "alsoKnowAs" TEXT;
