-- AlterTable
ALTER TABLE "Category" ADD COLUMN     "isPopular" BOOLEAN NOT NULL DEFAULT false;
