-- AlterTable
ALTER TABLE "Package" ADD COLUMN     "showIn" TEXT,
ADD COLUMN     "subtitle" TEXT,
ADD COLUMN     "title" TEXT;
