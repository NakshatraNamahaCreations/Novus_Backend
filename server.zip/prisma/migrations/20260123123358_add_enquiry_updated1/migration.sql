-- AlterTable
ALTER TABLE "Enquiry" ALTER COLUMN "name" DROP NOT NULL;
