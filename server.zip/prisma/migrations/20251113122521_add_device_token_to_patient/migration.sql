-- AlterTable
ALTER TABLE "Patient" ADD COLUMN     "deviceToken" TEXT;
