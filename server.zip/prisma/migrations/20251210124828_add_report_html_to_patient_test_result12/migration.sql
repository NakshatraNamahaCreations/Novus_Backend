-- AlterEnum
ALTER TYPE "PaymentStatus" ADD VALUE 'COMPLETED';
