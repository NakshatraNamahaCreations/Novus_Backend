-- DropIndex
DROP INDEX "public"."Patient_contactNo_key";
