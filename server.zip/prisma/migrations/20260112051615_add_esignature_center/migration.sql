-- AlterEnum
ALTER TYPE "Alignment" ADD VALUE 'CENTER';
