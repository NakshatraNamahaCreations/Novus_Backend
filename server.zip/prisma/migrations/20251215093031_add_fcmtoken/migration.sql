-- AlterTable
ALTER TABLE "Patient" ADD COLUMN     "fcmToken" TEXT;
