-- AlterTable
ALTER TABLE "Slot" ADD COLUMN     "endTime" TEXT;
