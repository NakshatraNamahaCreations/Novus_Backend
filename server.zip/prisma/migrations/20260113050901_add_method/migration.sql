-- AlterTable
ALTER TABLE "TestParameter" ADD COLUMN     "method" TEXT;
