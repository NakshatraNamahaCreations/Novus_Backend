-- AlterTable
ALTER TABLE "Patient" ADD COLUMN     "aadharNo" TEXT,
ADD COLUMN     "address" TEXT,
ADD COLUMN     "passportNo" TEXT;
