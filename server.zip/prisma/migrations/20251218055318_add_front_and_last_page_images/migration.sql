-- AlterTable
ALTER TABLE "ReportLayout" ADD COLUMN     "frontPageLastImg" TEXT,
ADD COLUMN     "lastPageImg" TEXT;
