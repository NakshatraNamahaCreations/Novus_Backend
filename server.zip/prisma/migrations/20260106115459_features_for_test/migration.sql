-- AlterTable
ALTER TABLE "Checkup" ADD COLUMN     "features" TEXT;

-- AlterTable
ALTER TABLE "Package" ADD COLUMN     "features" TEXT;
