-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "diagnosticCenterId" INTEGER,
ADD COLUMN     "source" TEXT;
